USE PruebaGenera
GO

CREATE UNIQUE INDEX UX_Marcacion_TrabajadorId_FechaHora_Tipo 
ON Marcacion (TrabajadorId, fechahora, Tipo);
GO