USE [PruebaGenera]
GO

CREATE NONCLUSTERED INDEX IX_Trabajador_EmpresaId_Activo ON dbo.Trabajador (EmpresaId ASC, Activo ASC) WITH (FILLFACTOR = 80);
GO