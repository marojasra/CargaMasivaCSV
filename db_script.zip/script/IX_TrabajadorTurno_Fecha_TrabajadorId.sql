USE [PruebaGenera]
GO

CREATE NONCLUSTERED INDEX IX_TrabajadorTurno_Fecha_TrabajadorId ON dbo.TrabajadorTurno (Fecha ASC, TrabajadorId ASC)
INCLUDE([TurnoId]) WITH (FILLFACTOR = 80) ON [PRIMARY]
GO