USE [PruebaGenera]
GO

CREATE NONCLUSTERED INDEX IX_Marcacion_TrabajadorId_FechaHora_Tipo ON dbo.Marcacion (TrabajadorId, FechaHora, Tipo)
INCLUDE (Origen)
with (fillfactor = 80);
GO