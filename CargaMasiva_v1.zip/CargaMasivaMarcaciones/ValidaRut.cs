﻿using System.Text.RegularExpressions;

namespace CargaMasivaMarcaciones
{
    public class ValidadorRut
    {
        public static (bool,string, string) ValidaRut(string rut)
        {
            if (string.IsNullOrEmpty(rut))
            {
                return (false, rut, "No existe rut");
            }

            rut = rut.Replace(".", "").ToUpper();
            Regex expresion = new Regex("^([0-9]+-[0-9K])$");
            string dv = rut.Substring(rut.Length - 1, 1);
            if (!expresion.IsMatch(rut))
            {
                return (false, rut + "-" + dv.ToUpper(),"Rut no válido");
            }
            char[] charCorte = { '-' };
            string[] rutTemp = rut.Split(charCorte);
            if (dv != Digito(int.Parse(rutTemp[0])))
            {
                return (false, rut + "-" + dv.ToUpper(), "Digito verificador incorrecto");
            }
            return (true, rut.Split(charCorte)[0] + "-" + dv.ToUpper(), "");
        }

        public static string Digito(int rut)
        {
            string respuesta = "";
            int suma = 0, multiplicador = 1;
            while (rut != 0)
            {
                multiplicador++;
                if (multiplicador == 8)
                    multiplicador = 2;
                suma += (rut % 10) * multiplicador;
                rut = rut / 10;
            }
            suma = 11 - (suma % 11);

            switch (suma)
            {
                case 11:
                    respuesta = "0";
                    break;
                case 10:
                    respuesta = "K";
                    break;
                default:
                    respuesta = suma.ToString();
                    break;
            }

            return respuesta;
        }
    }
}

