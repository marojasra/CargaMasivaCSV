﻿
namespace CargaMasivaMarcaciones
{
    public class Marcacion
    {
        public required string Rut { get; set; }
        public DateTime FechaHora { get; set; }
        public char Tipo { get; set; }
        public string Origen { get; set; }
        public int NroLinea { get; set; }
        public string Observacion { get; set; }
    }
}
