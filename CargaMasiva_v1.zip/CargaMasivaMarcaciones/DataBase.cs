﻿using Microsoft.Data.SqlClient;
using Dapper;
using Microsoft.Extensions.Configuration;

namespace CargaMasivaMarcaciones
{
    public class ResultadoCarga
    {
        public int InsertadosCount { get; set; }
        public List<(Marcacion Registro, string MotivoError)> Rechazados { get; set; } = new();
    }

    public class DataBase
    {
        // Build de la configuración leyendo appsettings.json
        static IConfiguration configuration = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
            .Build();

        // Obtener la cadena de conexión
        public static readonly string? connectionString = configuration.GetConnectionString("DefaultConnection");

        //public static readonly string connectionString = "Server=localhost;Database=PruebaGenera;Trusted_Connection=false;TrustServerCertificate=false;";

        public static ResultadoCarga CargarMarcacionesConAislamiento(List<Marcacion> listaMarcaciones)
        {
            var resultado = new ResultadoCarga();

            string sqlInsert = @"declare @EmpresaId as int = 1, @Activo as bit = cast(1 as bit), @TrabajadorId INT;
            SELECT  @TrabajadorId = TrabajadorId 
            FROM    dbo.Trabajador 
            WHERE EmpresaId = @EmpresaId 
              AND Activo = @Activo 
              AND Rut = @Rut;

            IF @TrabajadorId IS NULL
            BEGIN
                -- Retornamos -1 si el RUT/Trabajador no existe
                SELECT -1;
                RETURN;
            END

            IF NOT EXISTS (select 1
                            FROM dbo.Trabajador t
                            LEFT JOIN dbo.Marcacion m ON m.TrabajadorId = t.TrabajadorId
                            WHERE t.EmpresaId   = @EmpresaId
                            AND t.Activo    = @Activo
                            and t.rut       = @rut
                            and m.fechahora = @fechaHora
                            and m.tipo      = @tipo
            )
            BEGIN
                INSERT INTO Marcacion (TrabajadorId, FechaHora, Tipo, Origen) 
                VALUES (@TrabajadorId, @FechaHora, @Tipo, @Origen);

                SELECT 1; -- Retorna 1 si se insertó
            END
            ELSE
            BEGIN
                SELECT 0; -- Retorna 0 si era duplicado
            END;";

            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // 1. Iniciamos UNA sola transacción para toda la carga
                using (SqlTransaction transaction = connection.BeginTransaction())
                {
                    int savepointIndex = 0;

                    foreach (var marcacion in listaMarcaciones)
                    {
                        savepointIndex++;
                        string savepointName = $"sp_{savepointIndex}";

                        try
                        {
                            // 2. Creamos un punto de guardado antes de intentar la fila
                            transaction.Save(savepointName);

                            // 3. Intentamos insertar usando Dapper asociando la transacción
                            int estado = connection.ExecuteScalar<int>(sqlInsert, marcacion, transaction: transaction);

                            if (estado == 1)
                            {
                                resultado.InsertadosCount++;
                            }
                            else 
                            {
                                resultado.Rechazados.Add((marcacion, $"RUT {marcacion.Rut} no ha sido insertado."));
                            }

                            //resultado.InsertadosCount++;
                        }
                        catch (SqlException ex)
                        {
                            // 4. Si la fila falla (ej: Violación de FK, CHECK constraint, NULL no permitido):
                            // Deshacemos ÚNICAMENTE los cambios desde este savepoint
                            transaction.Rollback(savepointName);

                            // Registrar la fila rechazada y la causa sin detener la carga
                            resultado.Rechazados.Add((marcacion, ex.Message));
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback(savepointName);
                            resultado.Rechazados.Add((marcacion, ex.Message));
                        }
                    }

                    // 5. Confirmamos la transacción: se guardan TODAS las filas que no fallaron
                    transaction.Commit();
                }
            }

            return resultado;
        }

    }
}
