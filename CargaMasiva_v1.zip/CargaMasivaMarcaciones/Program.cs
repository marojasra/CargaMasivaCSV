﻿using CargaMasivaMarcaciones;

string rutaCsv = "marcaciones.csv";
string rutaRechazados = "rechazados.csv";

List<Marcacion> listaOriginal = [], listaSinDuplicados = [], listaRechazados = [];
List<string> rechazados = [];

if (File.Exists(rutaRechazados))
{
    File.Delete(rutaRechazados);
}

if (File.Exists(rutaCsv))
{
    var estadosValidos = new HashSet<string> { "E", "S" };
    // Leer todas las líneas del archivo
    string[] lineas = await File.ReadAllLinesAsync(rutaCsv);
    int contar = 0;

    foreach (string linea in lineas)
    {
        contar += 1;

        if (string.IsNullOrWhiteSpace(linea)) continue;

        string[] columnas = [.. linea.Split(';')];
        string rut = columnas[0];
        string[] nuevoRechazados = [];

        if (rut == "rut") 
        {
            nuevoRechazados = [.. columnas, "N°Linea", "observacion"];
            rechazados.Add(string.Join(";", nuevoRechazados));
            continue;
        }

        (bool, string, string) respuesta = ValidadorRut.ValidaRut(rut);
        if (!respuesta.Item1)
        {
            nuevoRechazados = [.. columnas, contar.ToString(), respuesta.Item3];
            rechazados.Add(string.Join(";", nuevoRechazados));
            //rechazados.Add(linea);
            continue;
        }

        string formatoFecha = "yyyy-MM-dd HH:mm:ss";
        if (!DateTime.TryParseExact(columnas[1], formatoFecha, System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out DateTime fechaConvertida))
        {
            nuevoRechazados = [.. columnas, contar.ToString(), "Fecha incorrecta"];
            rechazados.Add(string.Join(";", nuevoRechazados));
            continue;
        }
    
        string estado = columnas[2];

        if (!estadosValidos.Contains(estado))
        {
            nuevoRechazados = [.. columnas, contar.ToString(), "Estado inexistente"];
            rechazados.Add(string.Join(";", nuevoRechazados));
            continue;
        }

        listaOriginal.Add(new Marcacion 
            {
                Rut = respuesta.Item2,
                FechaHora = fechaConvertida,
                Tipo = Convert.ToChar(columnas[2]),
                Origen = columnas[3],
                NroLinea = contar
            }
        );

        
    }

    if (rechazados.Count > 0)
        await File.WriteAllLinesAsync(rutaRechazados, rechazados);

    ResultadoCarga resultado = new();
    if (listaOriginal.Count > 0)
    {
        listaSinDuplicados = listaOriginal
            .DistinctBy(x => new { x.Rut, x.FechaHora, x.Tipo})
            .ToList();

        resultado = DataBase.CargarMarcacionesConAislamiento(listaSinDuplicados);
    }
    
    Console.WriteLine($"Leídas: {lineas.Count() - 1}, Aceptadas: {resultado.InsertadosCount}, Rechazados: {resultado.Rechazados}");
}
else
{
    Console.WriteLine("El archivo no existe.");
}
