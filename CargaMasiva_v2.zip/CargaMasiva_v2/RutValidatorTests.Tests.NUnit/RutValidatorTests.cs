using NUnit.Framework;
using CargaMasiva_v2.Services;

namespace RutValidatorTests.Tests.NUnit
{
    [TestFixture]
    public class RutValidatorTests
    {
        [TestCase("9.876.543-3", "9876543-3")]
        [TestCase("09876543-3", "9876543-3")]
        [TestCase("12345678-5", "12345678-5")]
        [TestCase("  12.345.678-5  ", "12345678-5")]
        [TestCase("12345678-K", "12345678-K")]
        [TestCase("12345678-k", "12345678-K")]
        public void ValidRut_ShouldNormalizeCorrectly(string rawRut, string expectedNormal)
        {
            bool isValid = RutValidator.ValidarRut(rawRut, out string normalized);

            Assert.That(isValid, Is.True);
            Assert.That(normalized, Is.EqualTo(expectedNormal));
        }

        [TestCase("9.876.543-9")] // Invalid DV
        [TestCase("00000-0")]      // Too short / empty body
        [TestCase("abcde-k")]      // Text body
        [TestCase("")]             // Empty string
        [TestCase(null)]           // Null string
        public void InvalidRut_ShouldReturnFalse(string rawRut)
        {
            bool isValid = RutValidator.ValidarRut(rawRut, out string normalized);

            Assert.That(isValid, Is.False);
            Assert.That(normalized, Is.Empty);
        }
    }
}