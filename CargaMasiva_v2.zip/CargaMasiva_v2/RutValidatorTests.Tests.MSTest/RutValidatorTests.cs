﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using CargaMasiva_v2.Services;

namespace RutValidatorTests.Tests.MSTest
{
    [TestClass]
    public class RutValidatorTests
    {
        [TestMethod]
        [DataRow("9.876.543-3", "9876543-3")]
        [DataRow("09876543-3", "9876543-3")]
        [DataRow("12345678-5", "12345678-5")]
        [DataRow("  12.345.678-5  ", "12345678-5")]
        [DataRow("12345678-K", "12345678-K")]
        [DataRow("12345678-k", "12345678-K")]
        public void ValidRut_ShouldNormalizeCorrectly(string rawRut, string expectedNormal)
        {
            bool isValid = RutValidator.ValidarRut(rawRut, out string normalized);

            Assert.IsTrue(isValid);
            Assert.AreEqual(expectedNormal, normalized);
        }

        [TestMethod]
        [DataRow("9.876.543-9")] // Invalid DV
        [DataRow("00000-0")]      // Too short / empty body
        [DataRow("abcde-k")]      // Text body
        [DataRow("")]             // Empty string
        [DataRow(null)]           // Null string
        public void InvalidRut_ShouldReturnFalse(string rawRut)
        {
            bool isValid = RutValidator.ValidarRut(rawRut, out string normalized);

            Assert.IsFalse(isValid);
            Assert.AreEqual(string.Empty, normalized);
        }
    }
}
