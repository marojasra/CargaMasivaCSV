using Xunit;
using CargaMasiva_v2.Services;

namespace RutValidatorTests.Tests.xUnit
{
    public class RutValidatorTests
    {
        [Theory]
        [InlineData("9.876.543-3", "9876543-3")]
        [InlineData("09876543-3", "9876543-3")]
        [InlineData("12345678-5", "12345678-5")]
        [InlineData("  12.345.678-5  ", "12345678-5")]
        [InlineData("12345678-K", "12345678-K")]
        [InlineData("12345678-k", "12345678-K")]
        public void ValidRut_ShouldNormalizeCorrectly(string rawRut, string expectedNormal)
        {
            bool isValid = RutValidator.ValidarRut(rawRut, out string normalized);

            Assert.True(isValid);
            Assert.Equal(expectedNormal, normalized);
        }

        [Theory]
        [InlineData("9.876.543-9")] // Invalid DV
        [InlineData("00000-0")]      // Too short / empty body
        [InlineData("abcde-k")]      // Text body
        [InlineData("")]             // Empty string
        [InlineData(null)]           // Null string
        public void InvalidRut_ShouldReturnFalse(string rawRut)
        {
            bool isValid = RutValidator.ValidarRut(rawRut, out string? normalized);

            Assert.False(isValid);
            Assert.Equal(string.Empty, normalized);
        }
    }
}