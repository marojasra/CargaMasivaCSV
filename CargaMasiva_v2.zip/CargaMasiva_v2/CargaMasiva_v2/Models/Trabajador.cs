﻿
namespace CargaMasiva_v2.Models
{
    public class Trabajador
    {
        public int TrabajadorId { get; set; }
        public int EmpresaId { get; set; }
        public string Rut { get; set; } = string.Empty;
        public string Nombre { get; set; } = string.Empty;

        /// <summary>
        /// Activo = 1
        /// Inactivo = 0
        /// </summary>
        public int Activo { get; set; } 
    }
}
