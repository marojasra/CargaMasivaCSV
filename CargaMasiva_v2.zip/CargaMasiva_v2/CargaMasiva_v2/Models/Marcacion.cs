﻿
namespace CargaMasiva_v2.Models
{
    public class Marcacion
    {
        public int MarcacionId { get; set; }
        public int TrabajadorId { get; set; }
        public DateTime FechaHora { get; set; }
        public string Tipo { get; set; } = string.Empty; // E or S
        public string Origen { get; set; } = string.Empty;

        /// <summary>
        /// campos agregados despues de la carga inicial
        /// </summary>
        public int NroLinea { get; set; }
        public string Observacion { get; set; } = string.Empty;
    }
}
