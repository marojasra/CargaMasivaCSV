﻿using CargaMasiva_v2.Models;
using Microsoft.Data.SqlClient;
using Dapper;

namespace CargaMasiva_v2.Services
{
    public class DatabaseService
    {
        private readonly string _connectionString;

        public DatabaseService(string connectionString)
        {
            _connectionString = connectionString;
        }

        /// <summary>
        /// Look up an active worker in Empresa 1 by normalized RUT
        /// </summary>
        public Trabajador? ObtenerTrabajadorActivoPorRut(string rutNormalizado, int empresaId)
        {
            const string sql = @"
                SELECT TrabajadorId, EmpresaId, Rut, Nombre, Activo 
                FROM Trabajador 
                WHERE Rut = @Rut AND Activo = 1 AND EmpresaId = @EmpresaId;";

            using var connection = new SqlConnection(_connectionString);
            return connection.QueryFirstOrDefault<Trabajador>(sql, new { Rut = rutNormalizado, EmpresaId = empresaId });
        }

        /// <summary>
        /// Check if a Marcacion already exists in the database
        /// </summary>
        public bool ExisteMarcacion(int trabajadorId, DateTime fechaHora, string tipo)
        {
            const string sql = @"
                SELECT COUNT(1) 
                FROM Marcacion 
                WHERE TrabajadorId = @TrabajadorId AND FechaHora = @FechaHora AND Tipo = @Tipo;";

            using var connection = new SqlConnection(_connectionString);
            return connection.ExecuteScalar<int>(sql, new { TrabajadorId = trabajadorId, FechaHora = fechaHora, Tipo = tipo }) > 0;
        }

        /// <summary>
        /// Insert a list of Marcaciones in a single transaction
        /// </summary>
        public void InsertarMarcacionesBatch(List<Marcacion> marcaciones)
        {
            if (marcaciones == null || marcaciones.Count == 0) return;

            using var connection = new SqlConnection(_connectionString);
            connection.Open();
            using var transaction = connection.BeginTransaction();

            try
            {
                const string sql = @"
                    INSERT INTO Marcacion (TrabajadorId, FechaHora, Tipo, Origen) 
                    VALUES (@TrabajadorId, @FechaHora, @Tipo, @Origen);";

                connection.Execute(sql, marcaciones, transaction);
                transaction.Commit();
            }
            catch (Exception)
            {
                transaction.Rollback();
                throw;
            }
        }
    }
}
