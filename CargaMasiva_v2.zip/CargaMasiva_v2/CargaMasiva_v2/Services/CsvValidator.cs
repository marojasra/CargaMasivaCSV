﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using CargaMasiva_v2.Models;

namespace CargaMasiva_v2.Services
{
    public class CsvValidator
    {
        private readonly DatabaseService _dbService;
        private readonly int _empresaId;

        public class ProcessingResult
        {
            public int TotalLinesRead { get; set; }
            public int AcceptedCount => ValidMarcaciones.Count;
            public int RejectedCount => RejectedRows.Count;
            public List<Marcacion> ValidMarcaciones { get; } = new();
            public List<RejectedRow> RejectedRows { get; } = new();
        }

        public class RejectedRow
        {
            public int NroLinea { get; set; }
            public string RutOriginal { get; set; } = string.Empty;
            public string MotivoRechazo { get; set; } = string.Empty;
        }

        public CsvValidator(DatabaseService dbService, int empresaId = 1)
        {
            _dbService = dbService;
            _empresaId = empresaId;
        }

        /// <summary>
        /// Reads, parses, and validates the CSV file, checking format, types, duplicates, and worker status.
        /// Valid rows are written into the DB within a single transaction if dryRun is false.
        /// </summary>
        public ProcessingResult ProcessFile(string csvPath, bool dryRun)
        {
            var result = new ProcessingResult();
            var lines = File.ReadAllLines(csvPath);

            if (lines.Length == 0)
            {
                return result;
            }

            // We keep track of duplicates within this file load using a hashset of keys (TrabajadorId_FechaHora_Tipo)
            var duplicateSet = new HashSet<string>();

            // The header row is line 1, data starts at index 1 (line 2)
            result.TotalLinesRead = 0;

            for (int i = 1; i < lines.Length; i++)
            {
                string rawLine = lines[i];
                int currentLineNumber = i + 1; // 1-indexed line numbers, line 1 is heading

                // Ignore completely empty or whitespace lines
                if (string.IsNullOrWhiteSpace(rawLine))
                {
                    continue;
                }

                result.TotalLinesRead++;

                // Split by semicolon ;
                string[] parts = rawLine.Split(';');
                if (parts.Length < 4)
                {
                    result.RejectedRows.Add(new RejectedRow
                    {
                        NroLinea = currentLineNumber,
                        RutOriginal = parts.Length > 0 ? parts[0] : "N/A",
                        MotivoRechazo = "La línea no tiene las 4 columnas requeridas (rut;fecha_hora;tipo;origen)"
                    });
                    continue;
                }

                string rawRut = parts[0]?.Trim() ?? "";
                string rawFechaHora = parts[1]?.Trim() ?? "";
                string rawTipo = parts[2]?.Trim() ?? "";
                string rawOrigen = parts[3]?.Trim() ?? "";

                // 1. Validate RUT format and checksum (modulo 11)
                if (!RutValidator.ValidarRut(rawRut, out string rutNormalizado))
                {
                    result.RejectedRows.Add(new RejectedRow
                    {
                        NroLinea = currentLineNumber,
                        RutOriginal = rawRut,
                        MotivoRechazo = "RUT inválido (formato incorrecto o dígito verificador módulo 11 incorrecto)"
                    });
                    continue;
                }

                // 2. Validate FechaHora format yyyy-MM-dd HH:mm:ss
                if (!DateTime.TryParseExact(rawFechaHora, "yyyy-MM-dd HH:mm:ss",
                        CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime parsedDateTime))
                {
                    result.RejectedRows.Add(new RejectedRow
                    {
                        NroLinea = currentLineNumber,
                        RutOriginal = rawRut,
                        MotivoRechazo = $"Fecha/Hora inválida o en formato incorrecto. Se requiere: yyyy-MM-dd HH:mm:ss. Recibido: '{rawFechaHora}'"
                    });
                    continue;
                }

                // 3. Validate Tipo (must be E or S)
                string normalizedTipo = rawTipo.ToUpper();
                if (normalizedTipo != "E" && normalizedTipo != "S")
                {
                    result.RejectedRows.Add(new RejectedRow
                    {
                        NroLinea = currentLineNumber,
                        RutOriginal = rawRut,
                        MotivoRechazo = $"Tipo de marcación inválido. Debe ser 'E' (Entrada) o 'S' (Salida). Recibido: '{rawTipo}'"
                    });
                    continue;
                }

                // 4. DB Check: Trabajador must exist, be active (Activo = 1), and belong to Empresa 1
                Trabajador? trabajador = null;
                try
                {
                    trabajador = _dbService.ObtenerTrabajadorActivoPorRut(rutNormalizado, _empresaId);
                }
                catch (Exception dbEx)
                {
                    result.RejectedRows.Add(new RejectedRow
                    {
                        NroLinea = currentLineNumber,
                        RutOriginal = rawRut,
                        MotivoRechazo = $"Error de conexión de Base de datos al buscar trabajador: {dbEx.Message}"
                    });
                    continue;
                }

                if (trabajador == null)
                {
                    result.RejectedRows.Add(new RejectedRow
                    {
                        NroLinea = currentLineNumber,
                        RutOriginal = rawRut,
                        MotivoRechazo = $"Trabajador con RUT '{rutNormalizado}' no existe, no está activo o no pertenece a la Empresa ID {_empresaId}"
                    });
                    continue;
                }

                // 5. Check for Duplicates in the CSV itself (In-memory file uniqueness)
                string duplicateKey = $"{trabajador.TrabajadorId}_{parsedDateTime:yyyyMMddHHmmss}_{normalizedTipo}";
                if (duplicateSet.Contains(duplicateKey))
                {
                    result.RejectedRows.Add(new RejectedRow
                    {
                        NroLinea = currentLineNumber,
                        RutOriginal = rawRut,
                        MotivoRechazo = $"Fila duplicada en el archivo para TrabajadorId {trabajador.TrabajadorId}, Fecha/Hora {parsedDateTime:yyyy-MM-dd HH:mm:ss} y Tipo {normalizedTipo}"
                    });
                    continue;
                }
                duplicateSet.Add(duplicateKey);

                // 6. Check for Duplicates already existing in DB
                bool existsInDb = false;
                try
                {
                    existsInDb = _dbService.ExisteMarcacion(trabajador.TrabajadorId, parsedDateTime, normalizedTipo);
                }
                catch (Exception dbEx)
                {
                    result.RejectedRows.Add(new RejectedRow
                    {
                        NroLinea = currentLineNumber,
                        RutOriginal = rawRut,
                        MotivoRechazo = $"Error al verificar duplicidad en BD: {dbEx.Message}"
                    });
                    continue;
                }

                if (existsInDb)
                {
                    result.RejectedRows.Add(new RejectedRow
                    {
                        NroLinea = currentLineNumber,
                        RutOriginal = rawRut,
                        MotivoRechazo = $"Registro ya existe en la Base de datos (Constraint UX_Marcacion_TrabajadorId_FechaHora_Tipo)"
                    });
                    continue;
                }

                // If valid, build system augmented Marcacion
                var marcacion = new Marcacion
                {
                    TrabajadorId = trabajador.TrabajadorId,
                    FechaHora = parsedDateTime,
                    Tipo = normalizedTipo,
                    Origen = rawOrigen,
                    NroLinea = currentLineNumber,
                    Observacion = "Fila validada y lista para inserción."
                };

                result.ValidMarcaciones.Add(marcacion);
            }

            // 7. DB Insert Transaction (Only if NOT dryRun and there are elements to write)
            if (!dryRun && result.ValidMarcaciones.Count > 0)
            {
                try
                {
                    _dbService.InsertarMarcacionesBatch(result.ValidMarcaciones);
                }
                catch (Exception txEx)
                {
                    throw new Exception($"Fallo catastrófico al insertar transacciones en lote: {txEx.Message}", txEx);
                }
            }

            return result;
        }

        /// <summary>
        /// Generates the rejection CSV report 'rechazos.csv' with a semicolon separator
        /// </summary>
        public void GenerateRejectionFile(string outputPath, List<RejectedRow> rejectedRows)
        {
            var csvBuilder = new StringBuilder();

            // Semicolon-delimited header with line number, rut and reject motif
            csvBuilder.AppendLine("nro_linea;rut;motivo");

            foreach (var row in rejectedRows)
            {
                // Escape semicolons inside motif if any
                string cleanMotif = row.MotivoRechazo.Replace(";", ",");
                csvBuilder.AppendLine($"{row.NroLinea};{row.RutOriginal};{cleanMotif}");
            }

            File.WriteAllText(outputPath, csvBuilder.ToString(), Encoding.UTF8);
        }
    }
}
