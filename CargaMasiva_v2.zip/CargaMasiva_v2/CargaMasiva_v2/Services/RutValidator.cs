﻿using System;

namespace CargaMasiva_v2.Services
{
    public class RutValidator
    {
        /// <summary>
        /// Validates a Chilean RUT using the modulo 11 check digit algorithm.
        /// Returns true if valid, alongside its standardized format (no dots, with hyphen, upper case DV, no leading zeros).
        /// </summary>
        public static bool ValidarRut(string rut, out string rutNormalizado)
        {
            rutNormalizado = string.Empty;
            if (string.IsNullOrWhiteSpace(rut))
            {
                return false;
            }

            // Remove dots, hyphens, and spaces
            string limpio = rut.Replace(".", "").Replace("-", "").Replace(" ", "").Trim();

            // Trim leading zeros
            limpio = limpio.TrimStart('0');

            if (limpio.Length < 2)
            {
                return false;
            }

            // Extract the body and the check digit (DV)
            string cuerpo = limpio.Substring(0, limpio.Length - 1);
            string dvOriginal = limpio.Substring(limpio.Length - 1).ToUpper();

            // The body must be a valid number
            if (!long.TryParse(cuerpo, out long cuerpoNum))
            {
                return false;
            }

            // Calculate verify digit
            string dvCalculado = CalcularDigitoVerificador(cuerpoNum);

            if (dvOriginal != dvCalculado)
            {
                return false;
            }

            // Format to standard: no dots, with hyphen, capitalized DV, no leading zeros
            rutNormalizado = $"{cuerpoNum}-{dvOriginal}";
            return true;
        }

        private static string CalcularDigitoVerificador(long rut)
        {
            string respuesta;
            long suma = 0, multiplicador = 2, tempRut = rut;

            while (tempRut > 0)
            {
                suma += (tempRut % 10) * multiplicador;
                tempRut /= 10;
                multiplicador++;
                if (multiplicador > 7)
                {
                    multiplicador = 2;
                }
            }

            long resto = suma % 11;
            long resultado = 11 - resto;

            switch (resultado)
            {
                case 11:
                    respuesta = "0";
                    break;
                case 10:
                    respuesta = "K";
                    break;
                default:
                    respuesta = resultado.ToString();
                    break;
            }
            
            return respuesta;
        }
    
    }
}
