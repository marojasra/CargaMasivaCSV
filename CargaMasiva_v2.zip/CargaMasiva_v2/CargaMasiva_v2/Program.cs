﻿using Microsoft.Extensions.Configuration;
using CargaMasiva_v2.Services;

namespace CsvProcessor
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=================================================================");
            Console.WriteLine("                Proceso y validación archivo CSV                 ");
            Console.WriteLine("=================================================================");

            // 1. Load appsettings.json Configuration
            var builder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true);
            IConfiguration configuration = builder.Build();

            string connectionString = configuration.GetConnectionString("DefaultConnection");

            // 2. Resolve File Path (Config Priority, Argument Fallback)
            string configCsvPath = configuration["CsvSettings:DefaultFilePath"] ?? "";
            string outputRejectionPath = configuration["CsvSettings:OutputRejectionPath"] ?? "rechazos.csv";
            int targetEmpresaId = int.TryParse(configuration["CsvSettings:EmpresaId"], out int empId) ? empId : 1;

            string csvPathToRead = "";

            if (!string.IsNullOrWhiteSpace(configCsvPath))
            {
                csvPathToRead = configCsvPath;
                //Console.WriteLine($"[Config] Prioritized CSV path loaded from configuration: '{csvPathToRead}'");
            }
            else if (args.Length > 0 && !string.IsNullOrWhiteSpace(args[0]))
            {
                csvPathToRead = args[0];
                //Console.WriteLine($"[Arguments] Falling back to command line argument CSV path: '{csvPathToRead}'");
            }
            else
            {
                csvPathToRead = "marcaciones.csv"; // Ultimate fallback
                //Console.WriteLine($"[Warning] No path provided in config or arguments. Using fallback: '{csvPathToRead}'");
            }

            // Check if dry run is specified via argument
            bool isDryRun = false;
            if (args.Length > 1 && args[1].Equals("--dry-run", StringComparison.OrdinalIgnoreCase))
            {
                isDryRun = true;
            }
            else if (configuration["CsvSettings:DryRun"] != null &&
                     bool.TryParse(configuration["CsvSettings:DryRun"], out bool configDryRun))
            {
                isDryRun = configDryRun;
            }

            if (isDryRun)
            {
                Console.WriteLine("[Modo] *** Simulación detectada *** No se insertarán registros en la Base de datos.");
            }

            // Verify input file exists
            if (!File.Exists(csvPathToRead))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"[Error] Archivo no encontrado: '{Path.GetFullPath(csvPathToRead)}'");
                Console.ResetColor();
                return;
            }

            Console.WriteLine($"Procesando...");
            //Console.WriteLine($"Database Target: localhost -> PruebaGenera");
            //Console.WriteLine("-----------------------------------------------------------------");

            try
            {
                // 3. Initialize Services
                var dbService = new DatabaseService(connectionString);
                var csvValidator = new CsvValidator(dbService, targetEmpresaId);

                Console.WriteLine("Extrayendo información del archivo");
                var result = csvValidator.ProcessFile(csvPathToRead, isDryRun);

                // 4. Print Summary to Console
                Console.WriteLine();
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("=================================================================");
                Console.WriteLine("                             Resumen                             ");
                Console.WriteLine("=================================================================");
                Console.ResetColor();
                Console.WriteLine($"Líneas Leídas: {result.TotalLinesRead,6}");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine($"  Aceptadas  : {result.AcceptedCount,6}");
                Console.ForegroundColor = result.RejectedCount > 0 ? ConsoleColor.Yellow : ConsoleColor.Gray;
                Console.WriteLine($"  Rechazadas : {result.RejectedCount,6}");
                Console.ResetColor();
                Console.WriteLine("=================================================================");

                if (isDryRun)
                {
                    Console.ForegroundColor = ConsoleColor.Magenta;
                    Console.WriteLine("  * Ejecución de Prueba: Validación correcta, 0 filas escritas *");
                    Console.ResetColor();
                    Console.WriteLine("=================================================================");
                }

                // 5. Generate output rechazos.csv if there are rejects
                if (result.RejectedRows.Count > 0)
                {
                    csvValidator.GenerateRejectionFile(outputRejectionPath, result.RejectedRows);
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine($"[Export] Archivo Rechazado generado correctamente: '{outputRejectionPath}'");
                    Console.ResetColor();
                }
                //else
                //{
                //    Console.ForegroundColor = ConsoleColor.Green;
                //    Console.WriteLine("[Success] Zero rows rejected! No rejection file was needed.");
                //    Console.ResetColor();
                //}

                Console.WriteLine("\nProceso finalizad");
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"\n[Error] : {ex.Message}");
                Console.WriteLine(ex.StackTrace);
                Console.ResetColor();
            }
        }
    }
}
