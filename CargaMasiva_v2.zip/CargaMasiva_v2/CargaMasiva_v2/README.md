﻿IA utilizada, Google IA Studio
- Ha desarrollado una interfaz web desde su plataforma, no obstante genera todos los archivos necesarios para generar la solución en visual studio, esto me permitió ir verificando el correcto funcionamiento
- No he realizado ningun cambio adicional o generar un nuevo prompt
- Este desarrollo me llevo mucho menos tiempo que su primera versión, aprox. 3 hrs con una pausa por la hora de almuerzo

- PROMT 

Requiero una solución en visual studio, una aplicación de consola que importe archivo csv, el cual tiene separador ; y su primera fila con encabezado.
- La ruta del archivo llega por argumento o configuración, prioriza la lectura del archivo por configuración.
- crea clases 
	* validar rut
	* validar campos de las columnas del csv
	* conexión BD

Una vez leído el archivo csv, las columnas son "rut, fecha_hora, tipo, origen", debes de agregar 2 nuevas columnas por sistema, el cual tenga el "nro linea" y "observacion"
- este debe tener validaciones antes de realizar cualquier proceso de inserción
- Válidar RUT (dígito verificador módulo 11) y normalizado al formato de la BD: sin puntos, con guion, DV en mayúscula y sin ceros a la izquierda 
Por ejemplo: 
	* 9.876.543-3 a 9876543-3
	* 09876543-3  a 9876543-3
- fecha con formato yyyy-MM-dd HH:mm:ss
- Ignorar las líneas vacías 
- fecha_hora parseable 
- Tipo E o S
- no debe existir duplicados
- Cada fila rechazada debe quedar con su motivo
 
- La tabla Marcacion, tiene los siguientes campos MarcacionId, TrabajadorId, FechaHora, Tipo, Origen.
- Para obtener TrabajadorId, debes generar una query a la tabla Trabajador estos son sus campos TrabajadorId, EmpresaId, Rut, Nombre, Activo.
- Trabajador debe existir (rut = @rut), activo (activo = 1) y pertenecer a la empresa 1 (empresaid = 1).
- La columna origen se guarda tal cual en Marcacion.Origen y no participa en la detección de duplicados.

- Validar antes de insertar, no deben existir duplicados los filtros a ocupar son trabajadorid, fecha_hora y tipo.
- He creado un indice unico en la tabla 

Puedes agregar índices o restricciones a Marcacion si lo explicas, sin cambiar sus columnas.

USE PruebaGenera
GO

CREATE UNIQUE INDEX UX_Marcacion_TrabajadorId_FechaHora_Tipo ON Marcacion (TrabajadorId, fechahora, Tipo);
GO

- Ocupa Dapper para la conexión hacia la Base de datos.
- las filas válidas se insertan en una sola transacción y las rechazadas no detienen la carga.
- Se debe generar un archivo de salida rechazos.csv con los mismo parametros del archivo original separador ; y con encabezado, con el número de línea del archivo original 
- el archivo debe estar compuesto por:
	* encabezado es la línea 1
	* RUT y el motivo 
- se debe generar un resumen en consola: leídas (filas de datos, sin encabezado)
- aceptadas y rechazadas 
- Si se ejecuta el programa no debe insertar nada, entregando el resumen antes indicado.

- Genera pruebas unitarias con xUnit, NUnit y MSTest.

- cadena de conexión por appsettings.json (localhost)
He dejado la cadena de cónexión Data Source=localhost;Initial Catalog=PruebaGenera;Integrated Security=True;Persist Security Info=False;Pooling=False;MultipleActiveResultSets=False;Encrypt=False;TrustServerCertificate=False;Command Timeout=0;

